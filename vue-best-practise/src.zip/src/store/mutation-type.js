// 新增和删除一条计划
export const SAVE_PLAN = 'SAVE_PLAN'
export const DELETE_PLAN = 'DELETE_PLAN'
// 增加时间或者减少总时间
// totalTime
export const ADD_TOTAL_TIME = 'ADD_TOTAL_TIME'
export const DEC_TOTAL_TIME = 'DEC_TOTAL_TIME'