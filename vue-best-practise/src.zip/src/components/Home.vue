<template>
    <div class="jumbotron">
        <h2>任务追踪</h2>
        <p>
            <strong>
                <router-link to="/time-entries">创建一个任务</router-link>
            </strong>
        </p>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
