import * as types from './mutation-type'
export default {
    [types.ADD_TOTAL_TIME] (state, time) {
        state.totalTime = state .totalTime + time
    }
}